class WorldModel {
  final String confirmed;
  final String recovered;
  final String deaths;

  WorldModel({
    this.confirmed,
    this.recovered,
    this.deaths,
  });
}