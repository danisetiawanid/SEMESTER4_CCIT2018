class IndonesiaModel {
  final int confirmed;
  final int recovered;
  final int deaths;
  

  IndonesiaModel(
      {this.confirmed, this.recovered, this.deaths,});
}
